=== Blog Bank Classic ===
Contributors: wpthemespace
Theme Name: Blog Bank Classic
Theme URI: 
Author: WP theme Space
Author URI: 
Description: Blog Bank Classic is an awesome wordpress animated free responsive blog and megazin WordPress theme. This is the child theme of Blog Bank theme. Blog Bank Classic is an ideal for blog and megazin site with morden animated touch to display your website very beautiful and good looking.  Blog Bank Classic is editable and super flexible new functionality. The theme has nice, beautiful and professional layouts. This theme is made for any search engine, SEO Compatible.  The theme is very simple and totally responsive.  Html5 and css3 based coded.  It is the blog and megazin theme so you can create awesome blog and megazin site by the Blog Bank Classic theme.
Stable tag: 1.0.7
Requires PHP: 5.6
Tags: blog, custom-logo, portfolio, one-column, two-columns, custom-header, custom-menu, featured-image-header, featured-images, flexible-header, full-width-template, sticky-post, threaded-comments, translation-ready 
Requires at least: 5.0
Tested up to:  6.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright License ==
Be 100% GPL and/or 100% GPL-compatible licensed.
Declare copyright and license explicitly. Use the license and license uri header slugs to style.css.
Declare licenses of any resources included such as fonts or images.
All code and design should be your own or legally yours. Cloning of designs is not acceptable.
Any copyright statements on the front end should display the user's copyright, not the theme author's copyright.

Blog Bank Classic WordPress Theme, Copyright 2019 WP theme Space
Blog Bank Classic is distributed under the terms of the GNU GPL

This theme is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.



== Description ==

Blog Bank Classic is an awesome wordpress animated free responsive blog and megazin WordPress theme. This is the child theme of Blog Bank theme. Blog Bank Classic is an ideal for blog and megazin site with morden animated touch to display your website very beautiful and good looking.  Blog Bank Classic is editable and super flexible new functionality. The theme has nice, beautiful and professional layouts. This theme is made for any search engine, SEO Compatible.  The theme is very simple and totally responsive.  Html5 and css3 based coded.  It is the blog and megazin theme so you can create awesome blog and megazin site by the Blog Bank Classic theme.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==
### Images:
License: All Images are licensed under CC0
License URI: https://creativecommons.org/publicdomain/zero/1.0/

* Screenshot image one and default header image: CC0 by free photos via pxhere (https://pxhere.com/en/photo/1442877 )


    Other images in screenshot are self created and all are under GPLv2.

    Other Images:
        screenshot.png self created GPLv2
        header.jpg self modified GPLv2


==*  Brand Icons ==
The use of these trademarks does not indicate endorsement 
* All brand icons are trademarks of their respective owners.
of the trademark holder by Font Awesome, nor vice versa.



== Changelog ==

= 1.0.7 ==
* New style added for header 
= 1.0.6 ==
* Added button style 
* Added footer style 
= 1.0.5 ==
* Menu style change
* Mobile Menu responsive issue fixed
* Footer style changed
= 1.0.4 ==
* Add some new style.
= 1.0.3 ==
* Remove wordpress.org from author uri
= 1.0.2 ==
* Same tag use redme.txt and style.css 
* Author uri removed
* Use correct Prefix
* Remove all social links
* Hide footer social link by default 
* escaping properly
= 1.0.1 ==
* Remove admin notice 
= 1.0.0 ==

* Released


 
	